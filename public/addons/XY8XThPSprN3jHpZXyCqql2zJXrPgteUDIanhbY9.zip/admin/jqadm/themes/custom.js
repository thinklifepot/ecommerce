/*
 * Custom paystack JS
 */
